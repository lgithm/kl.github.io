<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<style>
			h1{
				margin: 200px auto;
				font-size: 130px;
			width: 400px;
				text-align: center;
			}
		</style>
	</head>
	<body>
		<h1>ERROR</h1>
	</body>
</html>